import React, { useState, useEffect, useMemo } from "react";
import { 
  Factory, 
  Users, 
  Package, 
  Truck, 
  AlertTriangle, 
  CheckCircle2, 
  BarChart3, 
  Download, 
  Play, 
  Settings,
  Plus,
  Trash2,
  Cpu,
  BrainCircuit
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { GoogleGenAI } from "@google/genai";

// --- Utils ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
interface Machine {
  id: string;
  name: string;
  capacity: number;
  status: "active" | "breakdown";
}

interface ScheduleItem {
  machineId: string;
  machineName: string;
  unitsAllocated: number;
  hoursNeeded: number;
  utilization: number;
}

interface Summary {
  totalDemand: number;
  actualDemand: number;
  shortage: number;
  totalProductionHours: number;
  totalDays: number;
  bottleneck: string;
  averageUtilization: number;
}

interface ScheduleResponse {
  schedule: ScheduleItem[];
  summary: Summary;
}

// --- Components ---

const Card = ({ children, className, title, icon: Icon }: { children: React.ReactNode; className?: string; title?: string; icon?: any }) => (
  <div className={cn("bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden", className)}>
    {title && (
      <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
        {Icon && <Icon className="w-4 h-4 text-blue-600" />}
        <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider">{title}</h3>
      </div>
    )}
    <div className="p-4">{children}</div>
  </div>
);

const StatCard = ({ label, value, subValue, icon: Icon, color = "blue" }: { label: string; value: string | number; subValue?: string; icon: any; color?: string }) => {
  const colors: Record<string, string> = {
    blue: "bg-blue-50 text-blue-600",
    amber: "bg-amber-50 text-amber-600",
    emerald: "bg-emerald-50 text-emerald-600",
    rose: "bg-rose-50 text-rose-600",
  };

  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-start gap-4">
      <div className={cn("p-3 rounded-lg", colors[color])}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500">{label}</p>
        <p className="text-2xl font-bold text-slate-900">{value}</p>
        {subValue && <p className="text-xs text-slate-400 mt-1">{subValue}</p>}
      </div>
    </div>
  );
};

export default function App() {
  // --- State ---
  const [demand, setDemand] = useState(5000);
  const [workers, setWorkers] = useState(10);
  const [rawMaterial, setRawMaterial] = useState(6000);
  const [delay, setDelay] = useState(2);
  const [machines, setMachines] = useState<Machine[]>([
    { id: "1", name: "Assembly Line A", capacity: 50, status: "active" },
    { id: "2", name: "Assembly Line B", capacity: 45, status: "active" },
    { id: "3", name: "CNC Machine 01", capacity: 30, status: "active" },
    { id: "4", name: "Injection Molder", capacity: 80, status: "active" },
  ]);

  const [scheduleData, setScheduleData] = useState<ScheduleResponse | null>(null);
  const [aiInsight, setAiInsight] = useState<string>("");
  const [isAiLoading, setIsAiLoading] = useState(false);

  // --- AI Setup ---
  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }), []);

  // --- Effects ---
  useEffect(() => {
    calculateSchedule();
  }, [demand, workers, rawMaterial, delay, machines]);

  const calculateSchedule = async () => {
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          demand,
          machines,
          workers,
          rawMaterial,
          supplyChainDelay: delay
        })
      });
      const data = await res.json();
      setScheduleData(data);
    } catch (err) {
      console.error("Failed to calculate schedule", err);
    }
  };

  const generateAiInsight = async () => {
    if (!scheduleData) return;
    setIsAiLoading(true);
    try {
      const prompt = `
        As an industrial engineering expert, analyze this production schedule:
        - Demand: ${demand} units
        - Machines: ${machines.length} (${machines.filter(m => m.status === 'breakdown').length} down)
        - Workers: ${workers}
        - Bottleneck: ${scheduleData.summary.bottleneck}
        - Avg Utilization: ${scheduleData.summary.averageUtilization}%
        - Total Days: ${scheduleData.summary.totalDays}
        - Material Shortage: ${scheduleData.summary.shortage} units

        Provide 3 concise, actionable insights to improve efficiency or mitigate risks. Keep it professional and technical.
      `;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      setAiInsight(result.text || "No insights available.");
    } catch (err) {
      setAiInsight("Failed to generate AI insights.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const exportToCSV = () => {
    if (!scheduleData) return;
    const headers = ["Machine", "Units Allocated", "Hours Needed", "Utilization (%)"];
    const rows = scheduleData.schedule.map(s => [
      s.machineName,
      s.unitsAllocated,
      s.hoursNeeded,
      s.utilization
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "production_schedule.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleMachineStatus = (id: string) => {
    setMachines(prev => prev.map(m => 
      m.id === id ? { ...m, status: m.status === "active" ? "breakdown" : "active" } : m
    ));
  };

  const addMachine = () => {
    const newId = (machines.length + 1).toString();
    setMachines([...machines, { id: newId, name: `New Machine ${newId}`, capacity: 40, status: "active" }]);
  };

  const removeMachine = (id: string) => {
    setMachines(prev => prev.filter(m => m.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Factory className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">Smart Planner AI</h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">Production Optimization</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={exportToCSV}
              className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
            <button 
              onClick={generateAiInsight}
              disabled={isAiLoading}
              className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50"
            >
              <BrainCircuit className="w-4 h-4" />
              {isAiLoading ? "Analyzing..." : "AI Insights"}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Inputs */}
          <div className="lg:col-span-4 space-y-6">
            <Card title="Production Parameters" icon={Settings}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5 flex items-center justify-between">
                    Demand Forecast (Units)
                    <span className="text-blue-600 font-bold">{demand.toLocaleString()}</span>
                  </label>
                  <input 
                    type="range" min="100" max="20000" step="100"
                    value={demand} onChange={(e) => setDemand(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5 flex items-center justify-between">
                    Available Workers
                    <span className="text-blue-600 font-bold">{workers}</span>
                  </label>
                  <input 
                    type="range" min="1" max="50"
                    value={workers} onChange={(e) => setWorkers(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5 flex items-center justify-between">
                    Raw Material (Units)
                    <span className="text-blue-600 font-bold">{rawMaterial.toLocaleString()}</span>
                  </label>
                  <input 
                    type="range" min="0" max="20000" step="100"
                    value={rawMaterial} onChange={(e) => setRawMaterial(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5 flex items-center justify-between">
                    Supply Chain Delay (Days)
                    <span className="text-blue-600 font-bold">{delay}</span>
                  </label>
                  <input 
                    type="range" min="0" max="14"
                    value={delay} onChange={(e) => setDelay(Number(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                </div>
              </div>
            </Card>

            <Card title="Resource Management" icon={Cpu}>
              <div className="space-y-3">
                {machines.map((machine) => (
                  <div key={machine.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        machine.status === "active" ? "bg-emerald-500 animate-pulse" : "bg-rose-500"
                      )} />
                      <div>
                        <p className="text-sm font-semibold text-slate-800">{machine.name}</p>
                        <p className="text-xs text-slate-500">{machine.capacity} units/hr</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => toggleMachineStatus(machine.id)}
                        className={cn(
                          "p-1.5 rounded-md text-xs font-medium",
                          machine.status === "active" ? "bg-amber-100 text-amber-700 hover:bg-amber-200" : "bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
                        )}
                      >
                        {machine.status === "active" ? "Breakdown" : "Repair"}
                      </button>
                      <button 
                        onClick={() => removeMachine(machine.id)}
                        className="p-1.5 bg-rose-100 text-rose-700 rounded-md hover:bg-rose-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
                <button 
                  onClick={addMachine}
                  className="w-full py-2 border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-sm font-medium hover:border-blue-300 hover:text-blue-500 transition-all flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Machine
                </button>
              </div>
            </Card>

            {/* AI Insights Panel */}
            <AnimatePresence>
              {aiInsight && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                >
                  <Card title="AI Intelligence" icon={BrainCircuit} className="bg-blue-50 border-blue-100">
                    <div className="prose prose-sm text-blue-900">
                      <p className="whitespace-pre-line leading-relaxed italic">
                        {aiInsight}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Right Column: Results */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Summary Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <StatCard 
                label="Production Time" 
                value={`${scheduleData?.summary.totalDays || 0} Days`}
                subValue={`${scheduleData?.summary.totalProductionHours || 0} Hours`}
                icon={Play} 
                color="blue" 
              />
              <StatCard 
                label="Bottleneck" 
                value={scheduleData?.summary.bottleneck || "N/A"}
                subValue="Highest Utilization"
                icon={AlertTriangle} 
                color="amber" 
              />
              <StatCard 
                label="Avg Utilization" 
                value={`${scheduleData?.summary.averageUtilization || 0}%`}
                subValue="Capacity Efficiency"
                icon={BarChart3} 
                color="emerald" 
              />
              <StatCard 
                label="Material Status" 
                value={scheduleData?.summary.shortage ? "Shortage" : "Ready"}
                subValue={scheduleData?.summary.shortage ? `${scheduleData.summary.shortage} units missing` : "All units covered"}
                icon={Package} 
                color={scheduleData?.summary.shortage ? "rose" : "emerald"} 
              />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <Card title="Machine Utilization (%)" icon={BarChart3}>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={scheduleData?.schedule || []}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="machineName" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        cursor={{ fill: '#f1f5f9' }}
                      />
                      <Bar dataKey="utilization" radius={[4, 4, 0, 0]}>
                        {(scheduleData?.schedule || []).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.utilization > 90 ? '#f43f5e' : entry.utilization > 70 ? '#f59e0b' : '#3b82f6'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card title="Workload Distribution" icon={Users}>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={scheduleData?.schedule || []}
                        dataKey="unitsAllocated"
                        nameKey="machineName"
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                      >
                        {(scheduleData?.schedule || []).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={['#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e'][index % 5]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </div>

            {/* Detailed Schedule Table */}
            <Card title="Detailed Production Schedule" icon={CheckCircle2}>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Machine</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Allocation</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Hours</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Utilization</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scheduleData?.schedule.map((item) => (
                      <tr key={item.machineId} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <p className="text-sm font-semibold text-slate-800">{item.machineName}</p>
                        </td>
                        <td className="py-4 px-4">
                          <p className="text-sm text-slate-600">{item.unitsAllocated.toLocaleString()} units</p>
                        </td>
                        <td className="py-4 px-4">
                          <p className="text-sm text-slate-600 font-mono">{item.hoursNeeded}h</p>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-3">
                            <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden min-w-[60px]">
                              <div 
                                className={cn(
                                  "h-full rounded-full",
                                  item.utilization > 90 ? "bg-rose-500" : item.utilization > 70 ? "bg-amber-500" : "bg-blue-500"
                                )}
                                style={{ width: `${item.utilization}%` }}
                              />
                            </div>
                            <span className="text-xs font-bold text-slate-700">{item.utilization}%</span>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <span className={cn(
                            "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                            item.utilization > 95 ? "bg-rose-100 text-rose-700" : "bg-emerald-100 text-emerald-700"
                          )}>
                            {item.utilization > 95 ? "Overloaded" : "Optimal"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Simulation Scenario Info */}
            <div className="bg-slate-800 rounded-xl p-6 text-white flex flex-col md:flex-row items-center gap-6">
              <div className="bg-slate-700 p-4 rounded-2xl">
                <Truck className="w-10 h-10 text-blue-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold mb-1">Simulation Mode Active</h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  Real-time adjustments are being processed. Any change to the input parameters will instantly recalculate the production flow and machine allocation.
                </p>
              </div>
              <button 
                onClick={() => {
                  setDemand(Math.floor(Math.random() * 10000) + 5000);
                  setWorkers(Math.floor(Math.random() * 20) + 5);
                  setDelay(Math.floor(Math.random() * 5));
                }}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 rounded-lg font-bold transition-all shadow-lg shadow-blue-900/20 whitespace-nowrap"
              >
                Simulate Scenario
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
