import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- Scheduling Logic ---
  interface Machine {
    id: string;
    name: string;
    capacity: number; // units per hour
    status: "active" | "breakdown";
  }

  interface SchedulingInput {
    demand: number; // total units needed
    machines: Machine[];
    workers: number;
    rawMaterial: number; // units available
    supplyChainDelay: number; // days
  }

  app.post("/api/schedule", (req, res) => {
    const { demand, machines, workers, rawMaterial, supplyChainDelay }: SchedulingInput = req.body;

    if (!demand || !machines || machines.length === 0) {
      return res.status(400).json({ error: "Invalid input" });
    }

    const activeMachines = machines.filter(m => m.status === "active");
    const totalCapacityPerHour = activeMachines.reduce((sum, m) => sum + m.capacity, 0);
    
    // Constraint: Workers can only operate a certain number of machines at once
    // Let's assume 1 worker per machine for simplicity, or limited by workers
    const effectiveCapacityPerHour = Math.min(totalCapacityPerHour, workers * (totalCapacityPerHour / activeMachines.length || 0));

    // Material constraint
    const maxProducible = rawMaterial;
    const actualDemand = Math.min(demand, maxProducible);
    const shortage = demand > maxProducible ? demand - maxProducible : 0;

    // Time calculation
    const productionHours = effectiveCapacityPerHour > 0 ? actualDemand / effectiveCapacityPerHour : Infinity;
    const totalDays = (productionHours / 8) + supplyChainDelay; // 8 hour shifts

    // Machine Utilization & Allocation
    const allocation = activeMachines.map(m => {
      const share = m.capacity / totalCapacityPerHour;
      const unitsAllocated = actualDemand * share;
      const hoursNeeded = unitsAllocated / m.capacity;
      const utilization = (hoursNeeded / (totalDays * 8)) * 100;

      return {
        machineId: m.id,
        machineName: m.name,
        unitsAllocated: Math.round(unitsAllocated),
        hoursNeeded: Number(hoursNeeded.toFixed(2)),
        utilization: Math.min(100, Number(utilization.toFixed(2)))
      };
    });

    // Bottleneck detection
    const bottleneck = allocation.reduce((prev, current) => (prev.utilization > current.utilization) ? prev : current, allocation[0]);

    res.json({
      schedule: allocation,
      summary: {
        totalDemand: demand,
        actualDemand,
        shortage,
        totalProductionHours: Number(productionHours.toFixed(2)),
        totalDays: Number(totalDays.toFixed(2)),
        bottleneck: bottleneck?.machineName || "None",
        averageUtilization: Number((allocation.reduce((sum, a) => sum + a.utilization, 0) / allocation.length || 0).toFixed(2))
      }
    });
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
